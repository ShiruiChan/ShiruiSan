"use client";
import React from "react";
import PortfolioApp from "@/src/pages/PortfolioApp";
export default function PortfolioAppClient() {
  return <PortfolioApp />;
}
