import "./App.css";
import PortfolioApp from "./pages/PortfolioApp";

function App() {
  return <PortfolioApp />;
}

export default App;
