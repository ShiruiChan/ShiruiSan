"use client";
import { motion } from "framer-motion";
import { useTheme } from "@/hooks/useTheme";
import { Moon, Sun } from "lucide-react";

export default function Footer() {
  const year = new Date().getFullYear();
  const { theme, setTheme } = useTheme(); // ← меняем toggleTheme на setTheme

  return (
    <footer className="relative mt-20 bg-gradient-to-b from-white/70 to-white/90 backdrop-blur dark:from-[rgba(0,0,0,0.25)] dark:to-[rgba(124,92,255,0.25)]  transition-colors duration-500">
      {/* декоративная линия */}
      <div className="pointer-events-none absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-slate-400/50 to-transparent dark:via-slate-600/50" />

      <div className="mx-auto w-[min(1100px,92%)] px-4 py-10">
        <div className="grid gap-10 md:grid-cols-3 md:gap-6">
          {/* Brand */}
          <div>
            <h3 className="text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
              ShiruiSan
            </h3>
            <p className="mt-2 max-w-sm text-sm text-slate-600 dark:text-slate-400">
              Frontend • UI/UX • Performance. I craft clean, fast interfaces
              with delightful micro-interactions.
            </p>
          </div>

          {/* Quick links */}
          <nav className="grid grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Navigate
              </p>
              {[
                "Home",
                "Projects",
                "Services",
                "Experience",
                "About",
                "Testimonials",
                "Contact",
              ].map((label) => (
                <a
                  key={label}
                  href={`#${label.toLowerCase()}`}
                  className="block text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white transition"
                >
                  {label}
                </a>
              ))}
            </div>

            <div className="space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Resources
              </p>
              {/* <a
                className="block text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
                href="/cv.pdf"
              >
                CV / Resume
              </a> */}
              <a
                className="block text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
                href="mailto:harlampevrenat@gmail.com"
              >
                Email
              </a>
              <a
                className="block text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
                href="https://t.me/ShiruiSan"
                target="_blank"
                rel="noreferrer"
              >
                Telegram
              </a>
              <a
                className="block text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
                href="https://github.com/ShiruiChan"
                target="_blank"
                rel="noreferrer"
              >
                GitHub
              </a>
            </div>
          </nav>

          {/* CTA card */}
          <motion.div
            initial={{ y: 10, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ type: "spring", stiffness: 140, damping: 18 }}
            className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white/90 dark:bg-[rgba(124,92,255,0.25)]/30 p-5 shadow-sm backdrop-blur transition-colors"
          >
            <p className="text-sm text-slate-700 dark:text-slate-300">
              Have a project in mind? Let’s build something great.
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <a
                href="#contact"
                className="inline-flex items-center justify-center rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:opacity-90 dark:bg-slate-100 dark:text-slate-900 transition"
              >
                Start a project
              </a>
              <button
                onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                className="inline-flex items-center justify-center rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700/40"
              >
                Back to top ↑
              </button>
            </div>
          </motion.div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-slate-200 dark:border-slate-700 pt-6 text-sm text-slate-500 dark:text-slate-400 md:flex-row">
          <p>© {year} ShiruiSan. All rights reserved.</p>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setTheme(theme === "light" ? "dark" : "light")} // ← тут переключаем
              className="rounded-xl border border-slate-300 dark:border-slate-600 p-2 transition hover:bg-slate-100 dark:hover:bg-slate-700/50"
              aria-label="Toggle theme"
              title="Toggle theme"
            >
              {theme === "light" ? (
                <Moon className="h-4 w-4 text-slate-700" />
              ) : (
                <Sun className="h-4 w-4 text-slate-200" />
              )}
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
