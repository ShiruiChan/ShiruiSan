import "./App.css";
import PortfolioApp from "./features/portfolio/PortfolioApp";

function App() {
  return <PortfolioApp />;
}

export default App;
